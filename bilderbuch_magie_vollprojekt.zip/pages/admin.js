
export default function Admin() {
  return (
    <div>
      <h1>Adminbereich</h1>
      <p>Hier können fertige PDFs verwaltet werden (Platzhalter).</p>
    </div>
  )
}
